﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe9Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 1;
            int x = 1;
            int aux = 0;

            Console.WriteLine("Os 30 primeiros valores da serie de fibonacci");


            while (x < 1000000)
            {
                Console.WriteLine(x);
                x = x + aux;
                aux = n;
                n = x;

            }

        }
    }
}
