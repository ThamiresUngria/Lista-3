﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe1Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            int x = 0;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite um valor positivo");
                n = int.Parse(Console.ReadLine());

            } while (n <= x);
            Console.WriteLine("Valor correto");
        }
    }
}
