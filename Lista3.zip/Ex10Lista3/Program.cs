﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe10Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double maior;
            double a, b, c, d, e, f, g, h, i, j;
            double soma;
            double ma;


            Console.WriteLine("Digite o 1º valor");
            a = Convert.ToInt32(Console.ReadLine());
            maior = a;

            Console.WriteLine("Digite o 2º valor");
            b = Convert.ToInt32(Console.ReadLine());
            if (b > maior)
            {
                maior = b;
            }

            Console.WriteLine("Digite o 3º valor");
            c = Convert.ToInt32(Console.ReadLine());
            if (c > maior)
            {
                maior = c;
            }

            Console.WriteLine("Digite o 4º valor");
            d = Convert.ToInt32(Console.ReadLine());
            if (d > maior)
            {
                maior = d;
            }

            Console.WriteLine("Digite o 5º valor");
            e = Convert.ToInt32(Console.ReadLine());
            if (e > maior)
            {
                maior = e;
            }

            Console.WriteLine("Digite o 6º valor");
            f = Convert.ToInt32(Console.ReadLine());
            if (f > maior)
            {
                maior = f;
            }

            Console.WriteLine("Digite o 7º valor");
            g = Convert.ToInt32(Console.ReadLine());
            if (g > maior)
            {
                maior = g;
            }

            Console.WriteLine("Digite o 8º valor");
            h = Convert.ToInt32(Console.ReadLine());
            if (h > maior)
            {
                maior = h;
            }

            Console.WriteLine("Digite o 9º valor");
            i = Convert.ToInt32(Console.ReadLine());
            if (i > maior)
            {
                maior = i;
            }


            Console.WriteLine("Digite o 10º valor");
            j = Convert.ToInt32(Console.ReadLine());
            if (j > maior)
            {
                maior = j;
            }

            Console.WriteLine("O maior valor: {0}", maior);


            soma = a + b + c + d + e + f + g + h + i + j;
            Console.WriteLine("A soma total: {0} ", soma);


            ma = soma / 10;
            Console.WriteLine("A media aritmetica dos valores é: {0}", ma);
            Console.ReadKey();
        }
    }
}
